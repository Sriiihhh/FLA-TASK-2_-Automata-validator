
def classify_character(char):
    """Classify a character into one of four alphabet groups."""

    if char in "ABCDEFGHIJKLMNOPQRSTUVWXYZ":
        return "U"

    elif char in "abcdefghijklmnopqrstuvwxyz":
        return "L"

    elif char in "0123456789":
        return "D"

    elif char in "!@#$%^&*()-_+=[]{};:,.?/":
        return "S"

    else:
        return None


def validate_password(password):
    """
    DFA for password policy validation.

    Rules:
    - Minimum 8 characters
    - Maximum 16 characters
    - At least one uppercase letter
    - At least one lowercase letter
    - At least one digit
    - At least one special character
    """

    # Bit values for required character categories
    category_bits = {
        "U": 1,
        "L": 2,
        "D": 4,
        "S": 8
    }

    # Initial DFA state
    count = 0
    mask = 0

    trace = [("START", "q0_0")]

    for char in password:

        category = classify_character(char)

        # Reject unsupported characters
        if category is None:
            trace.append((char, "qD"))
            return False, trace, "qD"

        # Reject passwords longer than 16 characters
        if count >= 16:
            trace.append((char, "qD"))
            return False, trace, "qD"

        # Update the number of characters
        count += 1

        # Remember the category encountered
        mask |= category_bits[category]

        # Construct the current DFA state
        state = f"q{count}_{mask}"

        trace.append((char, state))

    # All four categories must be present
    accepted = (8 <= count <= 16) and (mask == 15)

    final_state = f"q{count}_{mask}"

    return accepted, trace, final_state
