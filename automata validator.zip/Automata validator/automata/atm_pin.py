
def validate_pin_format(pin):
    """
    DFA for validating an exactly four-digit ATM PIN.
    """

    state = "q0"

    transitions = {
        "q0": "q1",
        "q1": "q2",
        "q2": "q3",
        "q3": "q4"
    }

    trace = [("START", state)]

    for char in pin:

        if state == "qD":
            trace.append((char, state))
            continue

        if char.isdigit():
            if state in transitions:
                state = transitions[state]
            else:
                state = "qD"
        else:
            state = "qD"

        trace.append((char, state))

    accepted = state == "q4"

    return accepted, trace, state


class ATMCard:
    """
    Demonstration of ATM card locking after
    three consecutive incorrect PIN attempts.
    """

    def __init__(self, correct_pin="4821"):
        self.correct_pin = correct_pin
        self.wrong_attempts = 0
        self.locked = False

    def submit_pin(self, pin):

        if self.locked:
            return "CARD LOCKED"

        valid, trace, final_state = validate_pin_format(pin)

        if not valid:
            return "INVALID PIN FORMAT"

        if pin == self.correct_pin:
            self.wrong_attempts = 0
            return "ACCESS GRANTED"

        self.wrong_attempts += 1

        if self.wrong_attempts >= 3:
            self.locked = True
            return "CARD LOCKED"

        return f"WRONG PIN - {3 - self.wrong_attempts} ATTEMPTS LEFT"
