
def classify_email_character(char):
    """Classify characters for the simplified email DFA."""

    if char.isascii() and char.isalpha():
        return "L"

    elif char.isascii() and char.isdigit():
        return "D"

    elif char in "_-+":
        return "O"

    elif char == "@":
        return "@"

    elif char == ".":
        return "."

    else:
        return "X"


def validate_email(email):
    """
    DFA for simplified email format validation.

    Rules:
    - Username must be present.
    - Exactly one @ symbol.
    - Domain must start with a letter.
    - Domain can contain letters and digits.
    - Dot must appear after the domain.
    - Extension must contain at least two letters.
    """

    state = "q0"

    transitions = {
        # Username
        "q0": {
            "L": "q1",
            "D": "q1",
            "O": "q1"
        },

        "q1": {
            "L": "q1",
            "D": "q1",
            "O": "q1",
            "@": "q2"
        },

        # First domain character MUST be a letter
        "q2": {
            "L": "q3"
        },

        # Remaining domain characters
        "q3": {
            "L": "q3",
            "D": "q3",
            ".": "q4"
        },

        # Extension
        "q4": {
            "L": "q5"
        },

        "q5": {
            "L": "q6"
        },

        "q6": {
            "L": "q6"
        }
    }

    trace = [("START", state)]

    for char in email:

        category = classify_email_character(char)

        state = transitions.get(state, {}).get(category, "qD")

        trace.append((char, state))

    accepted = state == "q6"

    return accepted, trace, state
