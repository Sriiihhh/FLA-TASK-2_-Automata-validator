
from automata.atm_pin import validate_pin_format, ATMCard
from automata.password import validate_password
from automata.email_validator import validate_email


# -------------------------------
# ATM PIN TEST CASES
# -------------------------------

def test_valid_atm_pin():
    accepted, trace, state = validate_pin_format("4821")
    assert accepted is True


def test_invalid_atm_pin_length():
    accepted, trace, state = validate_pin_format("123")
    assert accepted is False


def test_atm_pin_with_letters():
    accepted, trace, state = validate_pin_format("12A4")
    assert accepted is False


def test_atm_card_locks_after_three_wrong_attempts():
    card = ATMCard(correct_pin="4821")

    card.submit_pin("1234")
    card.submit_pin("5678")
    result = card.submit_pin("9999")

    assert result == "CARD LOCKED"
    assert card.locked is True


# -------------------------------
# PASSWORD TEST CASES
# -------------------------------

def test_valid_password():
    accepted, trace, state = validate_password("Srm@2026")
    assert accepted is True


def test_password_without_uppercase():
    accepted, trace, state = validate_password("password@123")
    assert accepted is False


def test_password_without_special_character():
    accepted, trace, state = validate_password("Password123")
    assert accepted is False


def test_password_too_short():
    accepted, trace, state = validate_password("Ab@123")
    assert accepted is False


def test_password_too_long():
    accepted, trace, state = validate_password("Abcdefgh@12345678")
    assert accepted is False


# -------------------------------
# EMAIL TEST CASES
# -------------------------------

def test_valid_email():
    accepted, trace, state = validate_email("sree@gmail.com")
    assert accepted is True


def test_email_without_at_symbol():
    accepted, trace, state = validate_email("sreegmail.com")
    assert accepted is False


def test_email_without_domain():
    accepted, trace, state = validate_email("sree@gmail")
    assert accepted is False


def test_email_domain_starting_with_digit():
    accepted, trace, state = validate_email("sree@04gmail.com")
    assert accepted is False


def test_email_with_two_at_symbols():
    accepted, trace, state = validate_email("sree@@gmail.com")
    assert accepted is False
