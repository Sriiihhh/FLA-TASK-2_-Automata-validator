
import streamlit as st
import pandas as pd
from pathlib import Path

from automata.atm_pin import validate_pin_format, ATMCard
from automata.password import validate_password
from automata.email_validator import validate_email


# -----------------------------------------
# PAGE CONFIGURATION
# -----------------------------------------

st.set_page_config(
    page_title="Automata Validator",
    page_icon="🔐",
    layout="wide"
)


# -----------------------------------------
# CUSTOM CSS - MINIMAL DESIGN
# -----------------------------------------

st.markdown("""
<style>

.stApp {
    background-color: #f7f8fa;
    color: #202938;
}

.block-container {
    max-width: 1150px;
    padding-top: 2rem;
    padding-bottom: 3rem;
}

h1, h2, h3 {
    color: #172b4d;
}

p, label, li {
    color: #465365;
}

.hero {
    background-color: #ffffff;
    padding: 28px 32px;
    border: 1px solid #e5e9f0;
    border-radius: 12px;
    margin-bottom: 22px;
}

.hero-label {
    color: #52749e;
    font-size: 13px;
    font-weight: 600;
    letter-spacing: 1.5px;
    text-transform: uppercase;
}

.hero-title {
    color: #172b4d;
    font-size: 34px;
    font-weight: 700;
    margin-top: 8px;
    margin-bottom: 8px;
}

.hero-description {
    color: #687588;
    font-size: 15px;
    margin-bottom: 0;
}

.section-card {
    background: #ffffff;
    border: 1px solid #e5e9f0;
    border-radius: 10px;
    padding: 18px;
    margin-bottom: 12px;
}

div.stButton > button {
    background-color: #294c75 !important;
    color: #ffffff !important;
    border: 1px solid #294c75 !important;
    border-radius: 7px;
    padding: 8px 18px;
    font-weight: 600;
}

div.stButton > button p {
    color: #ffffff !important;
}

div.stButton > button:hover {
    background-color: #1d395a !important;
    color: #ffffff !important;
    border-color: #1d395a !important;
}

div.stButton > button:hover p {
    color: #ffffff !important;
}

div.stButton > button:hover {
    background-color: #1d395a;
    color: white;
    border-color: #1d395a;
}

div[data-testid="stTextInput"] input {
    border-radius: 7px;
}

div[data-testid="stTabs"] button {
    font-weight: 600;
}

hr {
    border-color: #e5e9f0;
}

.footer {
    color: #8993a2;
    font-size: 12px;
    text-align: center;
    padding-top: 15px;
}

</style>
""", unsafe_allow_html=True)


# -----------------------------------------
# HEADER
# -----------------------------------------

st.markdown("""
<div class="hero">
    <div class="hero-label">Finite Automata Project</div>
    <div class="hero-title">Automata Validator</div>
    <p class="hero-description">
        An interactive platform for validating ATM PINs,
        passwords and email addresses using Deterministic
        Finite Automata.
    </p>
</div>
""", unsafe_allow_html=True)


# -----------------------------------------
# COMMON FUNCTIONS
# -----------------------------------------

def display_result(accepted):
    if accepted:
        st.success("ACCEPTED — Input satisfies the DFA rules.")
    else:
        st.error("REJECTED — Input does not satisfy the DFA rules.")


def display_trace(trace, final_state):
    st.markdown("#### State Transition Trace")

    data = [
        {"Input Symbol": char, "State": state}
        for char, state in trace
    ]

    st.dataframe(
        pd.DataFrame(data),
        use_container_width=True,
        hide_index=True
    )

    st.info(f"Final State: {final_state}")


def display_diagram(filename):
    image_path = Path("diagrams") / filename

    st.markdown("#### DFA State Diagram")

    if image_path.exists():
        st.image(str(image_path), use_container_width=True)
    else:
        st.info(
            f"Diagram not found: {filename}. "
            "Run the diagram generator to create it."
        )


# -----------------------------------------
# ATM SESSION
# -----------------------------------------

if "atm_card" not in st.session_state:
    st.session_state.atm_card = ATMCard()


# -----------------------------------------
# NAVIGATION
# -----------------------------------------

atm_tab, password_tab, email_tab, about_tab = st.tabs([
    "ATM PIN",
    "Password",
    "Email",
    "About"
])


# =========================================
# ATM PIN VALIDATION
# =========================================

with atm_tab:

    st.header("ATM PIN Validation")

    st.write(
        "Validates an exactly four-digit PIN and demonstrates "
        "card locking after three incorrect PIN attempts."
    )

    st.markdown("""
    <div class="section-card">
        <b>Validation rules</b>
        <ul>
            <li>PIN must contain exactly four digits.</li>
            <li>Only numeric characters are permitted.</li>
            <li>Three incorrect valid-format PIN attempts lock the demo card.</li>
        </ul>
    </div>
    """, unsafe_allow_html=True)

    st.caption("Demonstration PIN: 4821 | Not connected to real banking.")

    pin = st.text_input(
        "Enter ATM PIN",
        type="password",
        key="atm_pin_input"
    )

    col1, col2 = st.columns([1, 1])

    with col1:
        check_pin = st.button(
            "Validate PIN",
            key="check_pin",
            use_container_width=True
        )

    with col2:
        reset_card = st.button(
            "Reset Simulation",
            key="reset_card",
            use_container_width=True
        )

    if reset_card:
        st.session_state.atm_card = ATMCard()
        st.success("ATM simulation has been reset.")

    if check_pin:

        if st.session_state.atm_card.locked:
            st.error("CARD LOCKED — No further attempts allowed.")

        else:
            valid_format, trace, final_state = validate_pin_format(pin)

            display_trace(trace, final_state)

            if not valid_format:
                st.error("INVALID PIN FORMAT — Enter exactly four digits.")

            else:
                result = st.session_state.atm_card.submit_pin(pin)

                if result == "ACCESS GRANTED":
                    st.success("ACCESS GRANTED — Correct PIN!")

                elif result == "CARD LOCKED":
                    st.error("CARD LOCKED — Three incorrect attempts reached.")

                else:
                    st.warning(result)

            st.write(
                f"Incorrect attempts: "
                f"{st.session_state.atm_card.wrong_attempts} / 3"
            )

    st.divider()
    display_diagram("atm_pin_dfa.png")


# =========================================
# PASSWORD VALIDATION
# =========================================

with password_tab:

    st.header("Password Validation")

    st.write(
        "Checks whether a password satisfies the defined "
        "security policy using a DFA."
    )

    st.markdown("""
    <div class="section-card">
        <b>Password requirements</b>
        <ul>
            <li>Minimum 8 and maximum 16 characters.</li>
            <li>At least one uppercase letter.</li>
            <li>At least one lowercase letter.</li>
            <li>At least one digit.</li>
            <li>At least one special character.</li>
        </ul>
    </div>
    """, unsafe_allow_html=True)

    password = st.text_input(
        "Enter password",
        type="password",
        key="password_input"
    )

    if st.button("Validate Password", key="validate_password"):
        accepted, trace, final_state = validate_password(password)

        display_result(accepted)
        display_trace(trace, final_state)

    st.divider()
    display_diagram("password_dfa.png")


# =========================================
# EMAIL VALIDATION
# =========================================

with email_tab:

    st.header("Email Validation")

    st.write(
        "Checks email addresses using character categories "
        "and DFA state transitions."
    )

    st.markdown("""
    <div class="section-card">
        <b>Email validation rules</b>
        <ul>
            <li>A username must appear before the @ symbol.</li>
            <li>Exactly one @ symbol is permitted.</li>
            <li>The domain must start with a letter.</li>
            <li>A dot must appear after the domain.</li>
            <li>The extension must contain at least two letters.</li>
        </ul>
    </div>
    """, unsafe_allow_html=True)

    email = st.text_input(
        "Enter email address",
        key="email_input"
    )

    if st.button("Validate Email", key="validate_email"):
        accepted, trace, final_state = validate_email(email)

        display_result(accepted)
        display_trace(trace, final_state)

    st.divider()
    display_diagram("email_dfa.png")


# =========================================
# ABOUT PROJECT
# =========================================

with about_tab:

    st.header("About the Project")

    st.write(
        "Automata Validator demonstrates the practical "
        "application of Deterministic Finite Automata in "
        "real-time input validation."
    )

    st.subheader("Applications")

    st.markdown("""
    1. ATM PIN format validation and card-lock simulation.
    2. Password policy validation.
    3. Email format validation.
    """)

    st.subheader("Technologies Used")

    st.markdown("""
    - Python
    - Streamlit
    - Pandas
    - Graphviz
    - Pytest
    """)

    st.subheader("Automata Concepts")

    st.markdown("""
    - Deterministic Finite Automata (DFA)
    - States and transitions
    - Initial and accepting states
    - Dead states
    - Input validation
    """)

    st.info(
        "This is an educational demonstration. "
        "The email and password rules are simplified, "
        "and ATM authentication is simulated."
    )


# -----------------------------------------
# FOOTER
# -----------------------------------------

st.divider()

st.markdown("""
<div class="footer">
    Finite Automata Project | Department of CSE (AIML)
</div>
""", unsafe_allow_html=True)
