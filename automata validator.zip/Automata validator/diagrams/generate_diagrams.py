
from graphviz import Digraph

# Create ATM PIN DFA
atm = Digraph("ATM_PIN_DFA", format="png")

atm.attr(
    rankdir="LR",
    label="ATM PIN Validation DFA",
    labelloc="t",
    fontsize="20"
)

atm.attr("node", shape="circle")

# States
atm.node("start", shape="point")
atm.node("q4", shape="doublecircle")
atm.node("qD", label="qD\nDead State")

# Initial transition
atm.edge("start", "q0")

# Valid digit transitions
atm.edge("q0", "q1", label="Digit")
atm.edge("q1", "q2", label="Digit")
atm.edge("q2", "q3", label="Digit")
atm.edge("q3", "q4", label="Digit")

# Invalid input transitions
atm.edge("q0", "qD", label="Non-digit")
atm.edge("q1", "qD", label="Non-digit")
atm.edge("q2", "qD", label="Non-digit")
atm.edge("q3", "qD", label="Non-digit")
atm.edge("q4", "qD", label="Extra digit")

# Dead state loop
atm.edge("qD", "qD", label="Any input")

# Generate PNG
atm.render(
    filename="atm_pin_dfa",
    directory="diagrams",
    cleanup=True
)

print("ATM PIN DFA generated successfully!")


# Create Password Validation DFA
password = Digraph("PASSWORD_DFA", format="png")

password.attr(
    rankdir="LR",
    label="Password Validation DFA",
    labelloc="t",
    fontsize="20"
)

password.attr("node", shape="circle")

# Initial and accepting states
password.node("start", shape="point")
password.node("q0", label="q0")
password.node("q1", label="q1")
password.node("q2", label="q2")
password.node("q3", label="q3")
password.node("q4", label="q4")
password.node("q5", label="q5")
password.node("q6", label="q6")
password.node("q7", label="q7")
password.node("q8", label="q8", shape="doublecircle")
password.node("qD", label="qD\nDead State")

# Initial transition
password.edge("start", "q0")

# Illustrative transitions
password.edge("q0", "q1", label="U / L / D / S")
password.edge("q1", "q2", label="Valid character")
password.edge("q2", "q3", label="Valid character")
password.edge("q3", "q4", label="Valid character")
password.edge("q4", "q5", label="Valid character")
password.edge("q5", "q6", label="Valid character")
password.edge("q6", "q7", label="Valid character")
password.edge("q7", "q8", label="Valid character")

# Invalid input
password.edge("q0", "qD", label="Unsupported character")
password.edge("qD", "qD", label="Any input")

# Generate PNG
password.render(
    filename="password_dfa",
    directory="diagrams",
    cleanup=True
)

print("Password DFA generated successfully!")



# =====================================
# EMAIL DFA DIAGRAM
# =====================================

email = Digraph("EMAIL_DFA", format="png")

email.attr(
    rankdir="LR",
    label="Email Validation DFA",
    labelloc="t",
    fontsize="20"
)

email.attr("node", shape="circle")

email.node("start", shape="point")
email.node("q6", shape="doublecircle")
email.node("qD", label="Dead State")

email.edge("start", "q0")

# Username
email.edge("q0", "q1", label="L, D, O")
email.edge("q1", "q1", label="L, D, O")
email.edge("q1", "q2", label="@")

# Domain
email.edge("q2", "q3", label="L")
email.edge("q3", "q3", label="L, D")
email.edge("q3", "q4", label=".")

# Extension
email.edge("q4", "q5", label="L")
email.edge("q5", "q6", label="L")
email.edge("q6", "q6", label="L")

# Invalid transitions
email.edge("q0", "qD", label="Invalid")
email.edge("q1", "qD", label="Invalid")
email.edge("q2", "qD", label="D / Invalid")
email.edge("q3", "qD", label="Invalid")
email.edge("q4", "qD", label="Invalid")
email.edge("q5", "qD", label="Invalid")
email.edge("q6", "qD", label="Invalid")

email.edge("qD", "qD", label="Any input")

email.render(
    filename="email_dfa",
    directory="diagrams",
    cleanup=True
)

print("Email DFA generated successfully!")
