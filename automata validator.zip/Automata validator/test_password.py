
from automata.password import validate_password

print("PASSWORD VALIDATION DFA")
print("-----------------------")

password = input("Enter a password: ")

accepted, trace, final_state = validate_password(password)

print("\nSTATE TRANSITION TRACE")

for char, state in trace:
    print(char, "->", state)

print("\nFinal State:", final_state)

if accepted:
    print("RESULT: ACCEPTED")
else:
    print("RESULT: REJECTED")
