
from automata.email_validator import validate_email

print("EMAIL VALIDATION DFA")
print("--------------------")

email = input("Enter an email address: ")

accepted, trace, final_state = validate_email(email)

print("\nSTATE TRANSITION TRACE")

for char, state in trace:
    print(char, "->", state)

print("\nFinal State:", final_state)

if accepted:
    print("RESULT: ACCEPTED")
else:
    print("RESULT: REJECTED")
